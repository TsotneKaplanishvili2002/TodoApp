﻿using System;
using System.Collections.Generic;

namespace TodoListManager
{
    class Program
    {
        static void Main(string[] args)
        {
            List<TodoItem> todoList = new List<TodoItem>();

            Console.WriteLine("Welcome to Todo List Manager!");

            bool keepRunning = true;
            while (keepRunning)
            {
                Console.WriteLine("\nChoose an option:");
                Console.WriteLine("1. Add a task");
                Console.WriteLine("2. Mark a task as completed");
                Console.WriteLine("3. Remove a task");
                Console.WriteLine("4. Display current tasks");
                Console.WriteLine("5. Clear all tasks");
                Console.WriteLine("6. Exit");

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Enter task name: ");
                        string taskName = Console.ReadLine();
                        todoList.Add(new TodoItem(taskName));
                        Console.WriteLine("Task added.");
                        break;
                    case "2":
                        Console.Write("Enter task number to mark as completed: ");
                        if (int.TryParse(Console.ReadLine(), out int completedTaskIndex))
                        {
                            if (completedTaskIndex >= 1 && completedTaskIndex <= todoList.Count)
                            {
                                todoList[completedTaskIndex - 1].Completed = true;
                                Console.WriteLine($"Task \"{todoList[completedTaskIndex - 1].Name}\" marked as completed.");
                            }
                            else
                            {
                                Console.WriteLine("Invalid task number.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Please enter a number.");
                        }
                        break;
                    case "3":
                        Console.Write("Enter task number to remove: ");
                        if (int.TryParse(Console.ReadLine(), out int removeTaskIndex))
                        {
                            if (removeTaskIndex >= 1 && removeTaskIndex <= todoList.Count)
                            {
                                todoList.RemoveAt(removeTaskIndex - 1);
                                Console.WriteLine("Task removed.");
                            }
                            else
                            {
                                Console.WriteLine("Invalid task number.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Please enter a number.");
                        }
                        break;
                    case "4":
                        Console.WriteLine("Current tasks:");
                        for (int i = 0; i < todoList.Count; i++)
                        {
                            string status = todoList[i].Completed ? "Completed" : "Incomplete";
                            Console.WriteLine($"{i + 1}. {todoList[i].Name} - {status}");
                        }
                        break;
                    case "5":
                        todoList.Clear();
                        Console.WriteLine("All tasks cleared.");
                        break;
                    case "6":
                        keepRunning = false;
                        break;
                    default:
                        Console.WriteLine("Invalid input. Please try again.");
                        break;
                }
            }

            Console.WriteLine("Thanks for using Todo List Manager!");
            Console.ReadLine();
        }
    }

    class TodoItem
    {
        public string Name { get; set; }
        public bool Completed { get; set; }

        public TodoItem(string name)
        {
            Name = name;
            Completed = false;
        }
    }
}
