Project idea: Todo list manager

A command-line Todo list manager that allows users to keep track of their tasks. The program allows the user to use functions such as:

1. Add a new task to their list
2. Mark the task as complete
3. Remove the task from their list
4. Show a list of their current tasks
5. Clear their entire to-do list

ქართულად:
პროექტის იდეა: სამუშაოების სიის მენეჯერი

ბრძანების ხაზის todo სიის მენეჯერი, რომელიც მომხმარებლებს საშუალებას აძლევს თვალყური ადევნონ თავიანთ ამოცანებს. პროგრამამ მომხმარებელს საშუალებას აძლევს გამოიყენოს ფუნქციები როგორებიცაა : 

1. დაამატეთ ახალი დავალება მათ სიაში
2. მონიშნეთ დავალება შესრულებულად
3. ამოიღეთ დავალება მათი სიიდან
4. აჩვენეთ მათი ამჟამინდელი ამოცანების სია
5. გაასუფთავეთ მათი დავალებების მთელი სია