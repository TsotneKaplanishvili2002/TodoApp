Through the program you will be able to add new contacts to the list,
the contacts consist of first name, last name, and number. You can also 
adjust any of them. Delete or search by number

ქართულად:

პროგრამის საშუალებით თქვენ შეძლებთ სიაში ახალი კონტაქტების დამატება,
კონტაქტები შედგება სახელებით, გვარებით და ნომრებით. ასევე შეგიძლიათ
შეცვალოს რომელიმე მათგანი. წაშალეთ ან მოძებნეთ ნომრით