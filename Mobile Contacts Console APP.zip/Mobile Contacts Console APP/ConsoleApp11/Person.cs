﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    public class Person
    {
        public string _Name { get; set; }
        public string _Lastname { get; set; }
        public int _Number { get; set; }
        public int _ID { get; set; }

        public Person(int id, string name, string lastname, int number)
        {
            _Name = name;
            _Lastname = lastname;
            _Number = number;
            _ID = id;
        }

        public override string ToString()
        {
            return "ID  " + _ID + "  Saxeli: " + _Name + "  Gvari: " + _Lastname + "  Number " + _Number;
        }
        
    }
}
