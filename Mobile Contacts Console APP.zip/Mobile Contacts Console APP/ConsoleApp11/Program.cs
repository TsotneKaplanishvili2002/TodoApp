﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            List<Person> personList = new List<Person>();
            personList.Add(new Person(1, "Cotne", "Kaplanishvili", 598736452));
            personList.Add(new Person(2, "Nika", "Avqopashvili", 597652347));
            personList.Add(new Person(3, "Elene", "Xaburzania", 595374635));
            for (int i = 1; i > 0; i++)
            {
                Console.WriteLine("[1] Type 1 to see the list");
                Console.WriteLine("[2] Type 2 to Add new data");
                Console.WriteLine("[3] Type 3 if you want to search for a person by number");
                Console.WriteLine("[4] Type 4 if you want to remove any person by number");
                Console.WriteLine("[5] Type 5 If you want to change any member");

                int newlist = int.Parse(Console.ReadLine());
                if  (newlist == 1) 
                {
                    Console.WriteLine();
                    Console.WriteLine(" The List : ");
                    foreach (Person ia in personList)
                    {
                        Console.WriteLine(ia);
                    }
                    Console.WriteLine();
                }
                if (newlist == 2)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter Name:");
                    string a = Console.ReadLine();
                    Console.WriteLine("Enter Lastname:");
                    string b = Console.ReadLine();
                    Console.WriteLine("Enter Mobile Number:");
                    int c = int.Parse(Console.ReadLine());
                    int id = personList.Count + 1;
                    personList.Add(new Person(id, a, b, c));
                    Console.WriteLine();
                    Console.WriteLine("New data added successfully! Type 1 to see the list");
                    Console.WriteLine();
                }
                if (newlist == 3)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter Number: ");
                    int number = int.Parse(Console.ReadLine());
                    var persons = personList.Find(s => s._Number == number);
                    Console.WriteLine();
                    Console.WriteLine("Member found : " + persons);
                    Console.WriteLine();
                }
                if (newlist == 4)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter Number: ");
                    int o = int.Parse(Console.ReadLine());
                    int phoneNumberToRemove = o;
                    Person personToRemove = personList.FirstOrDefault(person => person._Number == phoneNumberToRemove);
                    if (personToRemove != null)
                    {
                        personList.Remove(personToRemove);
                    }
                    Console.WriteLine();
                    Console.WriteLine("You have deleted the member on this number! Type 1 to see the list");
                    Console.WriteLine();
                }
                if (newlist == 5)
                {
                    Console.WriteLine();
                    Console.WriteLine("Enter member ID to edit ! ");
                    int id = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Name: ");
                    string a = Console.ReadLine();
                    Console.WriteLine("Enter Lastname: ");
                    string b = Console.ReadLine();
                    Console.WriteLine("Enter Number: ");
                    int c = int.Parse(Console.ReadLine());
                    Person personToInsert = new Person(id, a, b , c);
                    personList.Insert(id - 1, personToInsert);
                    personList.RemoveAt(id);
                    Console.WriteLine("Data has been changed successfully ! Type 1 to see the list");
                    Console.WriteLine();

                }

            }
            

        }
    }
}
